#include<stdio.h>
void display();
void show();
int main()
{
printf("assignment given by manindra sir");
display();
show();
return 0;

}
