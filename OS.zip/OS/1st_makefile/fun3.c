void show()
{
printf("just\r\n");
}
