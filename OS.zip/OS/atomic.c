#include <unistd.h>
#include <stdio.h>
#include <pthread.h>

int lock = 1;
int count = 10;

void* increment(void* data)
{
//    while (1)
    {
        while ( !lock == 1);
        {
            lock--;               // "take" the lock
            count++;
            printf("Inc: %d\n", count);
            sleep(1);
            lock++;               // "release" the lock
        }
//	else{
//		printf("locked by thread 2");
//	}
    }
}

void* decrement(void* data)
{
  //  while (1)
    {
        while (!lock == 1);
        {
            lock--;               // "take" the lock
            count--;
            printf("Dec: %d\n", count);
            sleep(1);
            lock++;               // "release" the lock
        }
//	 else{
    //            printf("locked by thread 1");
  //      }

    }
}

int main()
{
    pthread_t tid1, tid2;

    pthread_create(&tid1, NULL, increment, NULL);
    pthread_create(&tid2, NULL, decrement, NULL);

    pthread_join(tid1, NULL);
    pthread_join(tid2, NULL);

    return 0;
}

