#include<stdio.h>
#include<pthread.h>
#include<unistd.h>
pthread_t t1,t2,t3,t4;
pthread_barrier_t barrier4;
void *lcd(void *data)
{
	printf("lcd init started\n");
	sleep(2);
	printf("lcd init end\n");
	pthread_barrier_wait(&barrier4);
	printf("lcd functionalty started\n");
}
void *serial(void *data)
{
	printf("serial init started\n");
        sleep(7);
        printf("serial init end\n");
        pthread_barrier_wait(&barrier4);
        printf("serial	functionalty started\n");
}
void *temp(void *data)
{
	printf("temp init started\n");
        sleep(5);
        printf("temp init end\n");
        pthread_barrier_wait(&barrier4);
        printf("temp functionalty started\n");
}
void *network(void *data)
{
	printf("network init started\n");
        sleep(10);
        printf("network init end\n");
        pthread_barrier_wait(&barrier4);
        printf("network functionalty started\n");
}
int main()
{
	pthread_barrier_init(&barrier4,NULL,4);
	pthread_create(&t1,NULL,lcd,NULL);
	pthread_create(&t2,NULL,serial,NULL);
	pthread_create(&t3,NULL,temp,NULL);
	pthread_create(&t4,NULL,network,NULL);
	pthread_join(t1,NULL);
	pthread_join(t2,NULL);
	pthread_join(t3,NULL);
	pthread_join(t4,NULL);
	pthread_barrier_destroy(&barrier4);
}
