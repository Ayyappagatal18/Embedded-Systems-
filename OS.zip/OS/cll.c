#include<stdio.h>
#include<stdlib.h>
struct node{
    int data;
    struct node * next;
};
struct node *start;
void insert_before(int n)
{
    struct node *temp,*cur;
        temp=(struct node*)malloc(sizeof(struct node));
    temp->data=n;
    temp->next=NULL;

    if(start==NULL)
    {
        start=temp;
    }
    else
    {
        cur=start;
        while(cur->next!=NULL)
        {

        
        cur=cur->next;
        }
        cur->next=temp;
    }
    // else
    // {
        
        // cur->next =temp;
        // temp->next=cur->next;
    // }
}

void travel_forward()
{
    struct node *cur=start;
    if(start==NULL)
    {
        printf("List is Empty");
    }
    while(cur!=NULL)
    {
        
        printf("%d->",cur->data);
        cur=cur->next;
     
    }
    printf("\n");
       
}


int cll()
{
    start =NULL;
    int choice;

    int flag=1;
    while(1 && flag==1)
    {
            printf("1)Add \n2)Display\n3)exit\n");
    scanf("%d",&choice);
   
    switch(choice)
    {
        case 1:int data;
                printf("Enert the data");
                scanf("%d",&data);
                insert_before(data);
                break;
        case 2:travel_forward();
                break;
        case 3: flag=0;
                break;
        default:printf("invalid input");
                break;
    }
}
    return 0;
}
