#include<stdio.h>
#include <sched.h>
#include <linux/sched.h>    /* Definition of struct clone_args */
#include <sched.h>          /* Definition of CLONE_* constants */
#include <sys/syscall.h> 
#include<sys/types.h>
#include <stdlib.h>
#include <signal.h>
#include<unistd.h>
#include<sys/wait.h>
void *child_func(void * data)
{
	int count= 1+1;
	printf("count= %d",count);
}
int main()

{
	int tid;
	char *stack = malloc(1024);
	tid= clone(child_func, stack, SIGCHLD, NULL);
	    waitpid(tid, NULL, 0);
	printf("tid= %d",tid);
	return 0;
}
