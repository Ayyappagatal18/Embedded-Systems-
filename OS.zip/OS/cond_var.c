#include<stdio.h>
#include<pthread.h>
#include<unistd.h>
int arr[2];
pthread_mutex_t lock;
pthread_cond_t cond;
void *fun1(void *arg)
{
	pthread_mutex_lock(&lock);
	arr[1]=10;
	pthread_cond_wait(&cond,&lock);
	printf("%d %d",arr[1],arr[0]);
	pthread_mutex_unlock(&lock);

}

void *fun2(void* arg)
{
	pthread_mutex_lock(&lock);
	arr[0]=20;
	arr[1]=30;
	pthread_cond_signal(&cond);
	pthread_mutex_unlock(&lock);
}
int main()
{
	pthread_mutex_init(&lock,NULL);

	pthread_cond_init(&cond,NULL);

	pthread_t th1,th2;
	
	pthread_create(&th1,NULL,fun1,NULL);

	pthread_create(&th2,NULL,fun2,NULL);
	
	pthread_join(th1,NULL);

	pthread_join(th1,NULL);

	pthread_mutex_destroy(&lock);

	pthread_cond_destroy(&cond);

}
