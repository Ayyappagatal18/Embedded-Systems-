#include<stdio.h>
void display();
int add(int a,int b);
int main()
{
	printf("cdac hyderabad\n");
	display();
	add(5,6);
	return 0;
}
