#include<stdio.h>
#include<pthread.h>
#include<unistd.h>
#include<semaphore.h>
sem_t lock;
int count= 10;

void *Inc(void *arg)
{
	while(1)
	{
		sem_wait(&lock);
		count++;
		printf("Inc: %d\n",count);
		sem_post(&lock);
	}
}
void *Dec(void *arg)
{
        while(1)
        {
                sem_wait(&lock);
                count--;
                printf("Dec: %d\n",count);
                sem_post(&lock);
        }
}

int main()
{
	pthread_t th1,th2;

	sem_init(&lock,0,1);
	
	pthread_create(&th1,NULL,Inc,NULL);

	pthread_create(&th2,NULL,Dec,NULL);

	pthread_join(th1,NULL);

	pthread_join(th2,NULL);

	sem_destroy(&lock);

}
