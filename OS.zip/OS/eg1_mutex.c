#include<stdio.h>
#include<pthread.h>
pthread_mutex_t lock;
int count=0;
void *incTh()
{
	while(1)
	{
		pthread_mutex_lock(&lock);
		count++;
		//sleep(1);
		printf("Inc:%d\n",count);

		pthread_mutex_unlock(&lock);
	}
}
void *decTh()
{
	while(1)
	{
		pthread_mutex_lock(&lock);
		count--;
		//sleep(1);
		printf("Dec: %d\n",count);
		pthread_mutex_unlock(&lock);
	}
}
int main()
{
	pthread_t th1,th2;

	pthread_mutex_init(&lock,NULL);

	pthread_create(&th1,NULL,incTh,NULL);
        pthread_create(&th2,NULL,decTh,NULL);

        pthread_join(th1,NULL);


	pthread_join(th2,NULL);

	pthread_mutex_destroy(&lock);

	return 0;
}



