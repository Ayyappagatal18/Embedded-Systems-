#include<stdio.h>
#include<string.h>
#include<sys/wait.h>
#include<unistd.h>
#include<fcntl.h>
int main()
{
	int pid1,pid2,pid3;
	pid1=fork();
	if(pid1==0)
	{
		int fd;
		fd=open("code.c",O_CREAT | O_WRONLY, S_IRWXU);
		printf("fd= %d",fd);
		if(fd==-1)
		{
			printf("file creation failed\n");
			return 1;
		}
		else
			printf("file created successfully \n");
		const char *code=
			"#include <stdio.h>\n"
			"int main() {\n"
			"	printf(\"Hello,World!\\n\");\n"
			"	return 0;\n"
			
			"}\n";	
		int ret;
		ret= write(fd,code,strlen(code));
		printf("length of string=%ld\n",strlen(code));
		printf("ret=%d\n",ret);
		if(ret==-1)
		{
			printf("fork failed\n");
			return 1;
		}
		else
			printf("write successfully\n");

		close(fd);
		printf("process 1 completed\n");
		return 0;
	}
	else if(pid1<0)
	{
		perror("process 1 failed\n");
		return 1;
	}
	else
	{
		
	//	execlp("gcc","gcc","code.c","-o","code",NULL);
	//	execlp("./code","code",NULL);
		wait(NULL);


	}
	//process 2
	pid2= fork();
	if(pid2==0)
	{
		int ret1;
		printf("process 2 completed\n");
		ret1=execlp("gcc","gcc","code.c","-o","code",NULL);
		//int ret3;
		//ret3=execlp("./code","code",NULL);
		if(ret1==-1)
		{
			perror("exec failed");
		}
		return 0;
	}
	else if(pid2<0)
	{
		perror("process 2 failed");
		return 1;
	}
	else
	{
		wait(NULL);
	}

	//process 3
	pid3=fork();
	if(pid3==0)
	{
		int ret2;
		printf("process 3 completed\n");
		ret2= execlp("./code","code",NULL);
		if(ret2==-1)
		{
			perror("exec failed");
			return 1;
		}
		return 0;

	}
	else if(pid3<0)
	{
		perror("process 3 failed");
		return 1;
	}
	else
	{
		wait(NULL);
	}

}
