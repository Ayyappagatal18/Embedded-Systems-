#include<stdio.h>
#include<pthread.h>
#include<unistd.h>
int lock=1;
int count=10;
void* increment(void* data)
{
	while(!lock==1 && count<=20);
	{
	lock--;
	count++;
	sleep(1);
	printf("Inc: %d\n",count);
	//wait(1);
	lock++;
	}
	printf("lock= %d\n",lock);
	return NULL;
}
void* decrement(void* data)
{
	while(!lock==1 && count>=10);
	{
	lock--;
	count--;
	sleep(1);
	printf("Dec: %d\n",count);
	//wait(1);
	lock++;
	}
}
int main()
{
	pthread_t tid1,tid2;
	
	pthread_create(&tid1,NULL,increment,NULL);
	
	pthread_create(&tid2,NULL,decrement,NULL);

	pthread_join(tid1,NULL);

	pthread_join(tid2,NULL);

	return 0;
}
	

