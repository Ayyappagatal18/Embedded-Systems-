#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

void *worker(void *arg) {

    printf("Thread working...\n");
    sleep(1);
    printf("Thread done.\n");

    return NULL;
}

int main() {
    pthread_t tid;
    pthread_attr_t attr;

    // Initialize attributes
    pthread_attr_init(&attr);

    // Set detach state using the macro constant
    pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);

    // Create a detached thread
    pthread_create(&tid, &attr, worker, NULL);

    // Attribute object no longer needed
    pthread_attr_destroy(&attr);

    printf("Main thread will not join. Detached thread cleans itself up.\n");
    //sleep(2);
      void *retval1;
    pthread_join(tid,&retval1);
    printf("main thread is done\n");



    return 0;
}

