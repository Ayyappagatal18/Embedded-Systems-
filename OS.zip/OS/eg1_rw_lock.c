#include<stdio.h>
#include<pthread.h>
pthread_rwlock_t lock;
int a=10;
int b=20;
void *fun1()
{
	pthread_rwlock_rdlock(&lock);
	printf("read 1: %d %d\n",a,b);
	pthread_rwlock_unlock(&lock);
	return NULL;
}
void *fun2()
{
	pthread_rwlock_rdlock(&lock);
	printf("read 2: %d %d\n",a,b);
	pthread_rwlock_unlock(&lock);
	return NULL;
}
void *fun3()
{
	pthread_rwlock_rdlock(&lock);
	printf("read 3: %d %d\n",a,b);
	pthread_rwlock_unlock(&lock);
	return NULL;
}
void *fun4()
{
	pthread_rwlock_wrlock(&lock);
	a++;
	b++;
	printf("write 1: %d %d\n",a,b);
	pthread_rwlock_unlock(&lock);
	return NULL;
}
void *fun5()
{
	pthread_rwlock_wrlock(&lock);
	a++;
	b++;
	printf("write 2: %d %d\n",a,b);
	pthread_rwlock_unlock(&lock);
	return NULL;
}

int main()
{
	pthread_rwlock_init(&lock,NULL);

	pthread_t th1,th2,th3,th4,th5;

	pthread_create(&th5,NULL,fun5,NULL);

	pthread_create(&th4,NULL,fun4,NULL);

	pthread_create(&th3,NULL,fun3,NULL);

	pthread_create(&th2,NULL,fun2,NULL);

	pthread_create(&th1,NULL,fun1,NULL);

	pthread_join(th1,NULL);

	pthread_join(th2,NULL);

	pthread_join(th3,NULL);

	pthread_join(th4,NULL);

	pthread_join(th5,NULL);

	pthread_rwlock_destroy(&lock);
}
