#include<stdio.h>
#include<pthread.h>
#include<unistd.h>
#include<semaphore.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<stddef.h>
sem_t lock;
int main()
{
	pthread_t th1,th2,th3,th4,th5,th6;
	void *fun1(void *arg);
	void *fun2(void *arg);
	void *fun3(void *arg);
	void *fun4(void *arg);
	void *fun5(void *arg);
	void *fun6(void *arg);





	sem_init(&lock,0,0);
	sem_init(&lock,0,1);
//	sem_init(&lock,0,3);

	pthread_create(&th1,NULL,fun1,NULL);
	pthread_create(&th2,NULL,fun2,NULL);
	pthread_create(&th3,NULL,fun3,NULL);
	pthread_create(&th4,NULL,fun4,NULL);
	pthread_create(&th5,NULL,fun5,NULL);
	pthread_create(&th6,NULL,fun6,NULL);
	
	pthread_join(th1,NULL);
	pthread_join(th2,NULL);
	pthread_join(th3,NULL);
	pthread_join(th4,NULL);
	pthread_join(th5,NULL);
	pthread_join(th6,NULL);

	sem_destroy(&lock);

//	sleep(5);
}

