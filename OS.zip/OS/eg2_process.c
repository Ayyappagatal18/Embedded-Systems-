#include<stdio.h>
#include<sys/types.h>
#include<unistd.h>
#include<fcntl.h>
#include<string.h>
#include<stdlib.h>
int main()
{
        pid_t child;
        int fd;
        char read_message[100];
        char write_message[]="hello how are you";
        child=fork();
        if(child==0)
        {
                printf("child processs created\n");
                fd=open("cdac.txt",O_WRONLY|O_CREAT,0777);
          	    	int gd=fork();
			if(gd==0)
			{
	      		write(fd,write_message,strlen(write_message));
				int cd=fork();
				if(cd==0)
				{
				execl("/bin/cat","cat","cdac.txt",NULL);
				exit(0);
				}
			}	
		exit(0);
	}
        
        if(child>execl("cat","cat","cdac.txt",NULL))
        {
                printf("good bye\n");
		return 0;
        }
}

