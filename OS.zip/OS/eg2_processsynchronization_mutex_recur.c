#include<stdio.h>
#include<unistd.h>

#include<pthread.h>
pthread_t t1;

pthread_mutex_t lock;
pthread_mutexattr_t attr1;

int i=0;

void* function_1(){
	while(1){// it is not mean thread calling again 
		pthread_mutex_lock(&lock);//it is meant for lock.
		pthread_mutex_lock(&lock);
		sleep(1);
		printf("Number: %d\n",i);
		i++;
		pthread_mutex_unlock(&lock);
		pthread_mutex_unlock(&lock);
	}

}
int main()
{
	pthread_mutexattr_init(&attr1);

	pthread_mutexattr_settype(&attr1,PTHREAD_MUTEX_RECURSIVE);

	pthread_mutex_init(&lock,&attr1);

	pthread_create(&t1,NULL,function_1,NULL);

	pthread_join(t1,NULL);

	printf("i am main\n");

	pthread_mutex_destroy(&lock);

	return 0;
}
