#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int thread_running = 0;        // Shared flag

void *worker(void *arg) {
    thread_running = 1;
    printf("Detached thread started.\n");
    sleep(3);                  // Simulate work
    printf("Detached thread finished.\n");
    thread_running = 0;        // Mark done
    return NULL;
}

int main() {
    pthread_t tid;
    pthread_attr_t attr;
    pthread_attr_init(&attr);
    pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);

    pthread_create(&tid, &attr, worker, NULL);
    pthread_attr_destroy(&attr);

    while (thread_running == 0) {
        // Wait until thread actually starts
        usleep(10000);
    }

    // Periodically check
    while (thread_running) {
        printf("Main: Thread is still running...\n");
        sleep(1);
    }

    printf("Main: Thread has finished.\n");
    return 0;
}

