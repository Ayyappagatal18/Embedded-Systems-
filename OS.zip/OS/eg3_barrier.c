#include<stdio.h>
#include<pthread.h>
pthread_barrier_t barrier;
void *lcd()
{
	printf("Lcd initialization\n");
	sleep(4);
	printf("Initialization completed\n");
	pthread_barrier_wait(&barrier);
	printf("lcd output\n");
}
void *uart()
{
	printf("uart initialization\n");
	sleep(5);
	printf("initialization completed\n");
	pthread_barrier_wait(&barrier);
	printf("uart ouput\n");
}
void *temp()
{
        printf("temp initialization\n");
        sleep(6);
        printf("initialization completed\n");
        pthread_barrier_wait(&barrier);
        printf("temp ouput\n");
}
void *oled()
{
        printf("oled initialization\n");
        sleep(4);
        printf("initialization completed\n");
        pthread_barrier_wait(&barrier);
        printf("oled ouput\n");
}

int main()
{
	pthread_t th1,th2,th3,th4;

	pthread_barrier_init(&barrier,NULL,4);

	pthread_create(&th1,NULL,lcd,NULL);
	pthread_create(&th2,NULL,uart,NULL);
	pthread_create(&th3,NULL,temp,NULL);
	pthread_create(&th4,NULL,oled,NULL);

	pthread_join(th1,NULL);
	pthread_join(th2,NULL);
	pthread_join(th3,NULL);
	pthread_join(th4,NULL);

}






