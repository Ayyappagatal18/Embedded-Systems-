#include<stdio.h>
#include<sys/types.h>
#include<unistd.h>
pid_t ret;
int main()
{

        printf("-----Before fork\n");
        printf("Pid: %d\n",getpid());
        printf("Ppid: %d\n",getppid());
	fork();
	if(ret!=fork())
	{	printf("%d",fork());
		sleep(2);
	}
	execl("/bin/ls"," ","-al",NULL);
        printf("-----After fork\n");
        printf("Pid: %d\n",getpid());
        printf("Ppid: %d\n",getppid());

return 0;
}

