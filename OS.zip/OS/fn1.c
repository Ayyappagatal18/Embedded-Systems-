void *fun1(void *arg)
{
	sem_t lock;
        printf("entering into thread1\n");
        sem_wait(&lock);
        printf("in thread 1\n");
        sem_post(&lock);
        printf("exiting thread1\n");
        return NULL;
}

