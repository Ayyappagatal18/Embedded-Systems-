void *fun2(void *arg)
{
	sem_t lock;
        printf("entering into thread2\n");
        sem_wait(&lock);
        printf("in thread 2\n");
        sem_post(&lock);
         printf("exiting thread2\n");
        return NULL;
}

