void *fun3(void *arg)
{
	sem_t lock;
         printf("entering into thread3\n");

        sem_wait(&lock);
        printf("in thread 3\n");
        sem_post(&lock);
           printf("exiting thread3\n");

        return NULL;
}

