void *fun4(void *arg)
{
	sem_t lock;
          printf("entering into thread4\n");

        sem_wait(&lock);
        printf("in thread 4\n");
        sem_post(&lock);
           printf("exiting thread4\n");

        return NULL;
}

