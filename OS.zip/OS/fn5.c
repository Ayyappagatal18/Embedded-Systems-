void *fun5(void *arg)
{
	sem_t lock;
          printf("entering into thread5\n");

        sem_wait(&lock);
        printf("in thread 5\n");
        sem_post(&lock);
              printf("exiting thread5\n");

        return NULL;
}

