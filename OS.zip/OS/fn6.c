void *fun6(void *arg)
{
	sem_t lock;
              printf("entering into thread6\n");
        sem_wait(&lock);
        printf("in thread 6\n");
        sem_post(&lock);
              printf("exiting thread6\n");

        return NULL;
}

