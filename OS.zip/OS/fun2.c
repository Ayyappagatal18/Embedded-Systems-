void display()
{
	printf("assignement given by manindra sir\n");
}
