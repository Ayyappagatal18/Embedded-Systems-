int add(int a,int b)
{
	int x=a;
	int y=b;
	
	printf("sum=%d\n",x+y);
}
