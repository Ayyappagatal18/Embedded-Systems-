#include<stdio.h>
void func1();
void func2();
int main()
{
        printf("cdac hyderabad\n");
        func1();
        func2();
}

