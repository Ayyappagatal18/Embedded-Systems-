#include<stdio.h>
void  func1()
{
	printf("opearting systems\n");
}

