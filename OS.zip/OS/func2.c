#include<stdio.h>
void func2()
{
	printf("microcontrollers\n");
}
