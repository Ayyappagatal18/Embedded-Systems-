#include<stdio.h>
#include<stdlib.h>
int main()
{
	FILE *fp1,*fp2;
	char c;
	fp1=fopen("file1.txt","w");
        if(fp1==NULL)
        {
                printf("error loading file\n");
                return -1;
        }

	fprintf(fp1,"hello");
	fclose(fp1);

	fp1=fopen("file1.txt","r");
        if(fp1==NULL)
        {
                printf("error loading file\n");
                return -1;
        }

	fp2=fopen("file2.txt","w");
	if(fp2==NULL)
	{
		printf("error in loading file\n");
		return -1;
	}
	
	while((c=fgetc(fp1))!=EOF)
	{
		
		fputc(c,fp2);
	}
	fclose(fp1);
	fclose(fp2);
	return 0;
}



