#include<stdio.h>
#include<mqueue.h>
#include<unistd.h>
#include<fcntl.h>
char buffer[40];
int main()
{
	mqd_t fd=mq_open("/mymsg",O_RDONLY);
	mq_receive(fd,buffer,sizeof(buffer),NULL);
	printf("received string:%s\n",buffer);
	mq_receive(fd,buffer,sizeof(buffer),NULL);
        printf("received string:%s\n",buffer);
	mq_close(fd);
}
