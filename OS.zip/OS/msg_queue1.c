#include<stdio.h>
#include <fcntl.h>           /* For O_* constants */
#include <sys/stat.h>        /* For mode constants */
#include <mqueue.h>
int main()
{
	 struct mq_attr msg;
               msg.mq_flags=0;       
                msg.mq_maxmsg=10;      
               msg.mq_msgsize=40;    
	       mqd_t fd=mq_open("/mymsg",O_CREAT | O_WRONLY,0777,&msg);
	       mq_send(fd,"hellocdac",10,0);
	       mq_send(fd,"hicdac",7,1);
	       mq_close(fd);
}

           


