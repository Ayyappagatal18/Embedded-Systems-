#include<stdio.h>
#include<pthread.h>
#include<unistd.h>
int count=20;
pthread_mutex_t lock;
void* inc(void* data)
{
	while(1)
	{
	pthread_mutex_lock(&lock);
	
	count++;
	sleep(0.1);
	printf("inc:%d\n",count);
	pthread_mutex_unlock(&lock);
	}
}
void* dec(void* data)
{
	while(1)
	{
		pthread_mutex_lock(&lock);
		count--;
		sleep(0.1);
		printf("dec:%d\n",count);
		pthread_mutex_unlock(&lock);
	}
}
int main()
{
	pthread_t tid1,tid2;
//	pthread_mutex_t lock;

	pthread_mutex_init(&lock,NULL);
	pthread_create(&tid1,NULL,inc,NULL);
	pthread_create(&tid2,NULL,dec,NULL);
	pthread_join(tid1,NULL);
	pthread_join(tid2,NULL);
	pthread_mutex_destroy(&lock);
}

