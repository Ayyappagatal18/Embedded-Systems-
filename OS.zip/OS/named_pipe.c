#include<stdio.h>
#include<unistd.h>
#include<fcntl.h>
char str[10];
int main()
{
	mkfifo("rwpipe",0666);
	int fd=open("rwpipe",O_RDONLY);
	read(fd,str,sizeof(str));
	printf("enter string:%s\n",str);
	close(fd);
}
