#include<stdio.h>
#include<unistd.h>
#include<fcntl.h>
char str[10];
int main()
{
	mkfifo("rwpipe",0666);
	int fd=open("rwpipe",O_WRONLY);
	printf("enter string:");
	scanf("%s",str);
	write(fd,str,sizeof(str));
	printf("string:%s\n",str);
	close(fd);
}
