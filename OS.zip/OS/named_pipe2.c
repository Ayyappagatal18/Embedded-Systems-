#include<stdio.h>
#include<unistd.h>
#include<fcntl.h>
int cnt;
int main()
{
	mkfifo("rwfile",0666);
	int fd=open("rwfile",O_RDONLY);
	read(fd,&cnt,sizeof(cnt));
	printf("count of vowels: %d",cnt);
	close(fd);
}



