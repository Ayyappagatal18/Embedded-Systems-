#include<stdio.h>
#include<unistd.h>
#include<fcntl.h>
char str[]="cdac hyderabad";
int count=0;
int count_vowels(char ch)
{
	switch(ch)
	{
		case 'a':count++;
			 break;
		case 'e':count++;
			 break;
		case 'i':count++;
			 break;
		case 'o':count++;
			 break;
		case 'u':count++;
			break;
	}
	return count;

}
			 	

int main()
{
	mkfifo("rwfile",0666);
	int fd=open("rwfile",O_WRONLY);
//	write(fd,count,sizeof(count));
	int i=0;
	int cnt=0;
	while(i<sizeof(str))
	{
		char c= str[i];

		 cnt=count_vowels(c);
	i++;
	}
	 write(fd,&cnt,sizeof(cnt));

	close(fd);
	printf("count in write process: %d",cnt);
	return 0;
}


