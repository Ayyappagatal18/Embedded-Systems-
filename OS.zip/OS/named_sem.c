#include<stdio.h>
#include<pthread.h>
#include <sys/mman.h>
#include <sys/stat.h>        /* For mode constants */
#include <fcntl.h>    
#include<semaphore.h>
char *str=0;


int main()
{
	int fd=shm_open("/cdac",O_CREAT | O_RDWR ,S_IRUSR | S_IWUSR);
	ftruncate(fd,sizeof(int));
	str=(int*)mmap(NULL,sizeof(int),PROT_READ | PROT_WRITE,MAP_SHARED,fd,0);
	
	sem_t *sem=sem_open("/cdac",O_CREAT | O_RDWR,S_IRUSR | S_IWUSR);
	sem_init(sem,1,1);
	sem_wait(sem);
	*str=0;
	sem_post(sem);
	while(1)
	{
		sem_wait(sem);
		(*str)++;
		printf("count=%d\n",(*str));
		sleep(1);
		sem_post(sem);
	}
	
}
	
