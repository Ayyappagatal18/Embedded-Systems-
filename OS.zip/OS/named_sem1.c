#include<stdio.h>
#include <fcntl.h>           /* For O_* constants */
#include <sys/stat.h>        /* For mode constants */
#include <semaphore.h>
#include<sys/types.h>
#include<sys/mman.h>
char *str;
//int count;


int main()
{
	int fd=shm_open("/cdac",O_CREAT | O_RDWR, S_IRUSR | S_IWUSR);
	ftruncate(fd,sizeof(int));
	str=(int*)mmap(NULL,sizeof(int),PROT_READ|PROT_WRITE,MAP_SHARED,fd,0);
	sem_t *sem=sem_open("/cdac",O_CREAT | O_RDWR, S_IRUSR | S_IWUSR);
	sem_init(sem,1,1);
//	sem_wait(sem);
//	count=0;
//	sem_post(sem);
	while(1)
	{
		sem_wait(sem);
//		sleep(1);
		printf("int:%d\n",(*str));
		sleep(1);

		sem_post(sem);
	}
}



