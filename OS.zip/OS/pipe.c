#include<stdio.h>
#include<sys/types.h>
#include<unistd.h>
int main()
{
	int fd[2];
	int pip;
	pip= pipe(fd);
	printf("return value of pipe= %d",pip);
	char str[10];
	int fd1;
	fd1=fork();
	if(fd1==0)
	{
		close(fd[1]);
		char buffer[10];
		read(fd[0],buffer,sizeof(buffer));
		printf("%s",buffer);
		close(fd[0]);
	}
	else if(fd1>0)
	{
		close(fd[0]);
		printf("Enter string\n");
		scanf("%s",str);
		write(fd[1],str,sizeof(str));
		close(fd[1]);
	}
return 0;
}


