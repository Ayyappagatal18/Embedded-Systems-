
int point()
{
int val= 10;
int *iptr;
iptr=&val;

printf("Value: %d\n",val);
printf("Value: %d\n",*iptr);
printf("Addr: %p\n",&val);
printf("Addr: %p\n",iptr);
printf("Size: %d\n",sizeof(iptr));
return 0;
}
