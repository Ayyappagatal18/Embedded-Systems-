#include<stdio.h>
#include<stdlib.h>
#include<pthread.h>
#include<unistd.h>

typedef struct{
	int a;
	int b;
}ThreadArgs;

//Thread function
void* compute_sum(void *arg)
{
	ThreadArgs* args= (ThreadArgs*) arg;

			int sum= args->a + args->b;

			printf("[Thread] Received a= %d,b= %d,sum= %d\n",args->a,args->b,sum);

			int * result= malloc(sizeof(int));
			*result= sum;
			//int result = sum;

//			return (void*)result;
		pthread_exit((void*) result);
}
int main()
{
	pthread_t thread;
	
	ThreadArgs args;

	args.a= 10;

	args.b= 25;

	int tid1=pthread_create(&thread,NULL,compute_sum,&args);
	printf("tid1= %d",tid1);

	if(tid1!=0)
	{
		perror("Failed to creat thread");

		return 1;
	}

	int* ret_val;
	int tid2=pthread_join(thread,(void**)&ret_val);
	printf("tid2= %d",tid2);
	if(tid2!=0)
	{
		perror("Failed to join thread\n");

		return 1;
	}
	printf("[Main] Thread returned sum= %d\n",*ret_val);

	free(ret_val);
	printf("[Main] Done.\n");
	return 0;
}

