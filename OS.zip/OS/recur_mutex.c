#include<stdio.h>
#include<pthread.h>
pthread_mutex_t lock;
pthread_mutexattr_t attr;
int count;
void *work()
{
	while(1)
	{
		pthread_mutex_lock(&lock);
		pthread_mutex_lock(&lock);
		count++;
		sleep(1);
		printf("count:%d\n",count);
		pthread_mutex_unlock(&lock);
		pthread_mutex_unlock(&lock);
	}
}

int main()
{
	pthread_t th1;
	

        pthread_mutexattr_init(&attr);
	
//	pthread_mutex_init(&lock,NULL);
	pthread_mutexattr_settype(&attr,PTHREAD_MUTEX_RECURSIVE);
//	pthread_mutexattr_init(&attr);
        pthread_mutex_init(&lock,&attr);
	
//	pthread_mutexattr_settype(&attr,PTHREAD_MUTEX_RECURSIVE);

	pthread_create(&th1,NULL,work,NULL);
	pthread_join(th1,NULL);

	pthread_mutex_destroy(&lock);
	pthread_mutexattr_destroy(&attr);
}




