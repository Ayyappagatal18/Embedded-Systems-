#include<stdio.h>
#include<pthread.h>
#include<semaphore.h>
sem_t key;
int count=8;
void *func1(void *data)
{
	sem_wait(&key);
	count++;
	printf("Inc:%d\n",count);
	sem_post(&key);
}
void *func2(void *data)
{
	sem_wait(&key);
	count--;
	printf("Dec:%d\n",count);
	sem_post(&key);
}
void *func3(void *data)
{
	sem_wait(&key);
	count=count+6;
	printf("Add:%d\n",count);
	sem_post(&key);
}
void *func4(void *data)
{
	sem_wait(&key);
	count=count-4;
	printf("sub:%d\n",count);
	sem_post(&key);
}
int main()
{
	pthread_t t1,t2,t3,t4;
//	sem_init(&key,0,0);
//	sem_init(&key,0,1);
	sem_init(&key,0,2);
	pthread_create(&t1,NULL,func1,NULL);
	pthread_create(&t2,NULL,func2,NULL);
	pthread_create(&t3,NULL,func3,NULL);
	pthread_create(&t4,NULL,func4,NULL);
	pthread_join(t1,NULL);
	pthread_join(t2,NULL);
	pthread_join(t3,NULL);
	pthread_join(t4,NULL);
	sem_destroy(&key);
}

