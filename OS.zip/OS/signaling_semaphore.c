#include<stdio.h>
#include<pthread.h>
#include<semaphore.h>
sem_t lock1,lock2;

void *fun1()
{	
	sem_wait(&lock1);
	printf("In thread 1\n");

}
void *fun2()
{
	sem_wait(&lock2);
	printf("In thread 2\n");
	sem_post(&lock1);
}
void *fun3()
{
	sem_post(&lock2);
	printf("In thread 3\n");
}

int main()
{
	pthread_t th1,th2,th3;
	sem_init(&lock1,0,0);
	sem_init(&lock2,0,0);
	pthread_create(&th1,NULL,fun1,NULL);
	pthread_create(&th2,NULL,fun2,NULL);
	pthread_create(&th3,NULL,fun3,NULL);
	pthread_join(th1,NULL);
        pthread_join(th2,NULL);
	pthread_join(th3,NULL);


}
