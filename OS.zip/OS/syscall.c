#include<stdio.h>
#include<fcntl.h>
#include<unistd.h>
int main()
{
	int fd;
	char buffer[12];
	fd=open("file3.txt",O_WRONLY |O_CREAT,0644);
	write(fd,"hello world",11);
	close(fd);
	fd=open("file3.txt",O_RDONLY | O_CREAT,0644);
	int fd1= open("file4.txt",O_WRONLY | O_CREAT,0644);
	while(read(fd,buffer,sizeof(buffer))>0)
	{
		write(fd1,buffer,sizeof(buffer));
	}
	close(fd);
	close(fd1);
return 0;
}

