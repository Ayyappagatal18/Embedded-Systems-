#include<stdio.h>
#include<sys/types.h>
#include<unistd.h>
#include<fcntl.h>
#include<string.h>
int main()
{
	pid_t child;
	int fd1,fd2;
	char read_message[100];
	char write_message[]="hello how are you";
	child=fork();
	if(child==0)
	{
		printf("child processs created\n");
		fd1=open("cdac.txt",O_WRONLY|O_CREAT,0777);
		write(fd1,write_message,strlen(write_message));
		close(fd1);
		fd1=open("cdac.txt",O_RDONLY|O_CREAT,0777);
		fd2=open("cdac1.txt",O_WRONLY|O_CREAT,0777);
		write(fd2,write_message,strlen(write_message));
		printf("%s\n",write_message);
		close(fd1);
		close(fd2);

	}
	if(child<0)
	{
		printf("child is not created\n");
	}
}

