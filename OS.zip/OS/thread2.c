#include<stdio.h>
#include<pthread.h>
#include<stdlib.h>
void* functioncall(void *data ){
	
	//*data= 50;
	int a= *(int *)data; 
	printf("\nhello pandian i am thread %d\n",a);
	
	return 0;
}

int main(){
	int a= 10;
	int *b= &a;
	pthread_t thread1,thread2,thread3;
	
	pthread_create(&thread1,NULL,functioncall,&a);

//	int retval;
	pthread_join(thread1,NULL);
	
	printf("retval=%d",a);

	return 0;
}


