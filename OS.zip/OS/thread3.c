#include<stdio.h>
#include<pthread.h>
#include<string.h>
struct data
{
	int data1;
	char data2[20];
	float data3;
};
void* thread(void* data)
{
	struct data *arg;
	arg=(struct data*)data;
	arg->data1=10+20;
	strcpy(	arg->data2,"reethu");
	arg->data3=5/2;
	return arg;
}
int main()
{
	pthread_t tid;
	struct data value;
	struct data *gcc;
	pthread_create(&tid,NULL,thread,&value);
	pthread_join(tid,(void*)&gcc);
	printf("data1=%d\ndata2=%s\ndata3=%0.2f\n",gcc->data1,gcc->data2,gcc->data3);
	return 0;
}

