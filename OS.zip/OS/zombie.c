#include<stdio.h>
#include<sys/types.h>
#include<unistd.h>
int main()
{
	pid_t pid;
	pid=fork();
	if(pid>0)
	{
		printf("pid:%d\n",getpid());
		printf("ppid:%d\n",getppid());
		sleep(30);
		printf("parent is sleeping and alive\n");
	}
	else if(pid==0)
	{
		printf("child is executing\n");
		printf("Child pid: %d",getpid());
	}
	else
	{
		printf("fork not workout\n");
	}
}
