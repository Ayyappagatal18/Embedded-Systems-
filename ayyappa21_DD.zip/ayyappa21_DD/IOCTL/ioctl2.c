#include <linux/module.h>
#include <linux/init.h>
#include <linux/cdev.h>
#include <linux/uaccess.h>
#include <linux/fs.h>
#include <linux/ioctl.h>
#include "func.h"
#define DFN "devicefile"
MODULE_LICENSE("GPL");
static dev_t dev_num;
static struct cdev cdev_r;
static char mbuff[50];
static struct class *my_class;

int attr_open(struct inode *inode, struct file *file);
int attr_release(struct inode *inode, struct file *file);
ssize_t attr_read(struct file *file, char __user *buf, size_t len, loff_t *ppos);
ssize_t attr_write(struct file *file, const char __user *buf, size_t len, loff_t *ppos);
static long int attr_ioctl(struct file *file, unsigned int cmd, unsigned long arg);
int attr_open(struct inode *inode, struct file *file)
{
    pr_info("file opened\n");
    return 0;
}
int attr_release(struct inode *inode, struct file *file)
{
    pr_info("file closed\n");
    return 0;
}
ssize_t attr_read(struct file *file, char __user *buf, size_t len, loff_t *ppos)
{
    pr_info("file read\n");
    return -EFAULT;
}
ssize_t attr_write(struct file *file, const char __user *buf, size_t len, loff_t *ppos)
{
    pr_info("file write\n");
    return -EFAULT;
   
}
static long int attr_ioctl(struct file *file, unsigned int cmd, unsigned long arg)
{
    switch (cmd)
    {
    case our_reset:
    {
        pr_info("reset done\n");
        break;
    }
    case our_write:
    {
        if (copy_from_user(mbuff, (char *)arg, sizeof(mbuff)))
            pr_err("error in write\n");
        pr_info("written data:%s\n", mbuff);
        break;
    }
    case our_read:
    {
        if (copy_to_user((char *)arg, mbuff, sizeof(mbuff)))
            pr_err("error in read\n");
        pr_info("data read\n");
        break;
    }
    default:
        pr_info("Default\n");
        break;
    }
    return 0;
}
static const struct file_operations fo = {
    .owner = THIS_MODULE,
    .open = attr_open,
    .release = attr_release,
    .read = attr_read,
    .write = attr_write,
    .unlocked_ioctl = attr_ioctl,
};
static int ioctl_entry(void)
{
    pr_info("in the main\n");
    alloc_chrdev_region(&dev_num, 0, 1, "mydrfile"); // driver name
    cdev_init(&cdev_r, &fo);
    cdev_add(&cdev_r, dev_num, 1);
    my_class = class_create("ss");                // sys/class
    device_create(my_class, NULL, dev_num, NULL, DFN); // dev file
    return 0;
}
static void ioctl_exit(void)
{
    // device_del(my_class);
    cdev_del(&cdev_r);
    unregister_chrdev_region(dev_num, 1);
    pr_info("exit the code\n");
}

module_init(ioctl_entry);
module_exit(ioctl_exit);
