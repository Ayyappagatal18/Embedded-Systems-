#include<stdio.h>
#include<string.h>
#include<fcntl.h>
#include<unistd.h>
#include<sys/ioctl.h>
#include "func.h"
#define DFN "/dev/devicefile"
int main()
{
    int fd;
    fd=open(DFN,O_RDWR);
    char str[]="hello from user space\n";
    ioctl(fd,our_write,str);
    char buff[50];
    ioctl(fd,our_read,buff);
    ioctl(fd,our_reset);
    printf("%s",buff);
    close(fd);
    return 0;
}