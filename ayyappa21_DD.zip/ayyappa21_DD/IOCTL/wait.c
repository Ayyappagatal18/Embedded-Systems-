#include<linux/init.h>
#include<linux/module.h>
#include<linux/fs.h>
#include<linux/uaccess.h>
#include<linux/wait.h>
#include<linux/cdev.h>
#define major 162
#define minor 0
DECLARE_WAIT_QUEUE_HEAD(wq);
MODULE_LICENSE("GPL");
static struct cdev m_cdev;
static int f = 0;
static dev_t dev = MKDEV(major,minor);
static char kr_buf[1024] = "hi from kernel";
static int op(struct inode *inode, struct file *file)
{
    pr_info("open.. \n");
    return 0;
}
static int re(struct inode *inode, struct file *file)
{
    pr_info("closed.. \n");
    return 0;
}
static ssize_t rd(struct file *file, char __user *buf,size_t len, loff_t *ppos)
{
    pr_info("reading.. \n");
    pr_info("Going into sleep..\n");
    if(copy_to_user(buf,kr_buf,len))
    {
        return -EFAULT;
    }
    wait_event_interruptible(wq,f == 1);
    pr_info("came out sleep.. \n");
    pr_info("read ---==>>> %s\n",kr_buf);
    return len;
}
static ssize_t wr(struct file *file, const char __user *buf,size_t len, loff_t *ppos)
{
    if (copy_from_user(kr_buf, buf, len))
        return -EFAULT;
        f=1;
    wake_up(&wq);
    pr_info("write ---==>>> %s\n",kr_buf);
    return 0;
}
static const struct file_operations fops = {
    .owner	 = THIS_MODULE,
    .open	 = op,
    .release = re,
    .read	 = rd,
    .write	 = wr,
};
static int m_init(void)
{
    pr_info("module installed..\n");
    register_chrdev_region(dev, 1, "queue_device");
    cdev_init(&m_cdev, &fops);
    cdev_add(&m_cdev, dev, 1);
    pr_info("char driver created.. \n");
    return 0;
}
static void m_exit(void)
{
    pr_info("Bye..\n");
    cdev_del(&m_cdev);
    unregister_chrdev_region(dev, 1);
}
module_init(m_init);
module_exit(m_exit);


#include<stdio.h>
#include<string.h>
#include <fcntl.h>
#include <unistd.h>
int main()
{
    int fp,a;
    char buf1[1024],buf2[1024];
    fp = open("/dev/mq_file",O_RDWR); 
    printf("1.read\n2.write\n");
    scanf("%d",&a);
    switch(a)
    {
        case 1:
        {
            read(fp,buf2,sizeof(buf2));
            printf("%s\n",buf2);
            break;
        }
        case 2:
        {
            printf("enter \n");
            // gets(buf1);
            scanf("%s",buf1);
            write(fp,buf1,strlen(buf1));
            break;
        }
    }
    close(fp);
    return 0;
} 