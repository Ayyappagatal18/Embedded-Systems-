#include<linux/module.h>
#include<linux/kernel.h>
#include<linux/param.h>
#include<linux/init.h>
MODULE_LICENSE("GPL");
static int a = 8;
static int ar[] = {1,4,5,6};
static char *s = "bkjvd";
static int m_init(void)
{
    pr_info("val = %d\n",a);
    for(int i = 0 ; i < 4 ; i++)
    {
        pr_info("arr = %d\n",ar[i]);
    }
    pr_info("str = %s\n",s);
    return 0;
}
static void m_exit(void)
{
    pr_info("hi\n");
}
module_param(a,int,S_IRWXU);
module_param_array(ar,int,NULL,S_IRWXU);
module_param(s,charp,S_IRWXU);
module_init(m_init);
module_exit(m_exit);