#include<stdio.h>
#include<string.h>
#include<fcntl.h>
#include<unistd.h>
#include<sys/ioctl.h>
// #include "fun.h"

int main()
{
    int fd;
    
    fd=open("/dev/assidevicefile",O_RDWR);
    int n,flag=0;
    char buff[50];
    while(1)
    {
        char str[100];
        printf("enter the number 1.read\t 2.write\t 3.ioctl\t 4.close\t:");
        scanf("%d",&n);
        switch(n)
        {
            case 1:
            {
                lseek(fd,0,SEEK_SET);
                read(fd,buff,sizeof(buff));
                printf("reading::%s\n",buff);
                break;
            }
            case 2:
            {
                printf("enter the word:");
                getchar();
                gets(str);
                write(fd,str,strlen(str)+1);
                printf("writting\n");
                break;
            }
            // case 3:
            // {
            //     ioctl(fd,io_write,str);
            //     ioctl(fd,io_read,buff);
            //     break;
            // }
            case 4:
            {
                close(fd);
                printf("closing\n");
                flag=1;
                break;
            }
            default:
            {
                break;
            }
        }
        if(flag==1)
        {
            break;
        }
    }
}



