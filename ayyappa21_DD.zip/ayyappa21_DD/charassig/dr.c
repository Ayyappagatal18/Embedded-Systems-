#include <linux/module.h>
#include <linux/init.h>
#include <linux/fs.h>
#include <linux/cdev.h>
#include <linux/uaccess.h>
#include <linux/device.h>
#define DF "assidevicefile"
MODULE_LICENSE("GPL");
static char kbuff[100];
static dev_t adev;
static struct class *c;
static struct cdev acdev;
int attr_open(struct inode *inode, struct file *file)
{
    pr_info("opened the file\n");
    return 0;
}
int attr_release(struct inode *inode, struct file *file)
{
    pr_info("closed the file\n");
    return 0;
}
ssize_t attr_read(struct file *file, char __user *buf, size_t len, loff_t *ppos)
{
    pr_info("read called\n");
    if (copy_to_user(buf, kbuff, len))
        return -EFAULT;
    return len;
}
ssize_t attr_write(struct file *file, const char __user *buf, size_t len, loff_t *ppos)
{
    pr_info("write called\n");
    if (*ppos + len > sizeof(kbuff))
        return -ENOSPC;
    if (copy_from_user(kbuff + *ppos, buf, len))
        return -EFAULT;
    if (kbuff[*ppos + len - 1] == '\0')
        len--;
    *ppos += len;
    pr_info("KERNAL STORED %s\n", kbuff);
    return len;
}

static const struct file_operations s = {
    .owner = THIS_MODULE,
    .open = attr_open,
    .release = attr_release,
    .read = attr_read,
    .write = attr_write,
    .llseek = default_llseek,
};
static int aentry(void)
{
    alloc_chrdev_region(&adev, 0, 1, "assidriverfile");
    cdev_init(&acdev, &s);
    cdev_add(&acdev, adev, 1);
    c = class_create(DF);
    device_create(c, NULL, adev, NULL, DF);
    return 0;
}
static void aexit(void)
{
    device_destroy(c, adev);
    class_destroy(c);
    cdev_del(&acdev);
    unregister_chrdev_region(adev, 1);
}

module_init(aentry);
module_exit(aexit);