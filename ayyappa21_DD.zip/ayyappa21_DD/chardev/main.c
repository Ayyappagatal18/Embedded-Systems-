#include<stdio.h>
#include<unistd.h>
#include<fcntl.h>

int main()
{
    char strng[50];
    char buff[]="who are you !!! duduuddudu";
    int fd=open("/dev/cdrivefile",O_RDWR,0666);
    write(fd,buff,sizeof(buff));
    // int fd1;
    read(fd,strng,sizeof(strng));
    printf("%s\n",strng);
    close(fd);
}