#include<linux/init.h>
#include<linux/module.h>
#include<linux/cdev.h>
#include<linux/fs.h>
#include<linux/uaccess.h>
MODULE_LICENSE("GPL");
static struct class *my_class;
static struct cdev m_cdev;
static dev_t dev;
static char kr_buf[100];
static int buf_len = 0; 
static int op(struct inode *inode, struct file *file)
{
    pr_info("opend.. \n");
    return 0;
}
static int rs(struct inode *inode, struct file *file)
{
    pr_info("closed... \n");
    return 0;
}
static ssize_t rd(struct file *file, char __user *buf,size_t len, loff_t *ppos)
{
    pr_info("reading... \n");
    if(copy_to_user(buf,kr_buf,buf_len))
    {
        pr_info("error in read\n");
        return -EFAULT;
    }
    return len;
}  
static ssize_t wr(struct file *file, const char __user *buf, size_t len, loff_t *ppos)
{
    pr_info("writing..\n"); 
    // Check if buffer has enough space
    if (buf_len + len + 1 >= sizeof(kr_buf)) {
        pr_info("Kernel buffer full\n");
        return -ENOMEM;
    }
    // Append new data at the end of the stored buffer
    if (copy_from_user(kr_buf + buf_len, buf, len)) {
        pr_info("error in writing\n");
        return -EFAULT;
    }
    buf_len += len;
    // Add a space after each write (optional but required for: hi hello)
    kr_buf[buf_len] = ' ';
    buf_len++;

    return len;
}
static const struct file_operations fops = {
	.owner	 = THIS_MODULE,
	.open	 = op,
	.release = rs,
	.read	 = rd,
	.write	 = wr,
};

static int ma_init(void)
{
    pr_info("module installed...\n");
    alloc_chrdev_region(&dev, 0, 1, "Assign_device");
    cdev_init(&m_cdev, &fops);
    cdev_add(&m_cdev, dev, 1);
    my_class = class_create("eo_class");
    device_create(my_class,NULL,dev,NULL,"Ass_file");
    pr_info("char deiver installed..\n");
    return 0;
}
static void ma_exit(void)
{
    pr_info("bye.. \n");
    device_destroy(my_class, dev);
    class_destroy(my_class);
    cdev_del(&m_cdev);
    unregister_chrdev_region(dev, 0);
}
module_init(ma_init);
module_exit(ma_exit);

