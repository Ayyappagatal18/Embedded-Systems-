#include<stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include<string.h>
int main()
{
    int fd;
    char buf1[100],buf2[100],buf3[100];
    fd = open("/dev/Ass_file", O_RDWR);
    while(1)
    {
    gets(buf1);
    write(fd,buf1,strlen(buf1));
    gets(buf2);
    write(fd,buf2,strlen(buf2));
    
    read(fd,buf3,sizeof(buf3));
    printf("read --==>> %s\n",buf3);
    }
    return 0;
}