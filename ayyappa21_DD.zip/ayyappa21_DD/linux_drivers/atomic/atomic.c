#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/atomic.h>

MODULE_LICENSE("GPL");
MODULE_AUTHOR("sai");
MODULE_DESCRIPTION("Simple atomic operations example");

static atomic_t counter = ATOMIC_INIT(0);

static int __init atomic_example_init(void)
{
    pr_info("ATOMIC_EX: Module loaded\n");

    atomic_inc(&counter);
    pr_info("ATOMIC_EX: After atomic_inc = %d\n", atomic_read(&counter));

    atomic_add(5, &counter);
    pr_info("ATOMIC_EX: After atomic_add(5) = %d\n", atomic_read(&counter));

    atomic_sub(2, &counter);
    pr_info("ATOMIC_EX: After atomic_sub(2) = %d\n", atomic_read(&counter));

    atomic_inc_return(&counter);
    pr_info("ATOMIC_EX: After atomic_inc_return = %d\n", atomic_read(&counter));

    return 0;
}

static void __exit atomic_example_exit(void)
{
    pr_info("ATOMIC_EX: Module unloaded\n");
}

module_init(atomic_example_init);
module_exit(atomic_example_exit);
