#include<linux/module.h>
#include<linux/init.h>
#include<linux/fs.h>
#include<linux/uaccess.h>
#include<linux/cdev.h>

MODULE_LICENSE("GPL");
static dev_t dev_num;
static struct cdev cdev;
static char kbuff[1024];

static int my_open(struct inode *inode, struct file *file){
    pr_info("file opened\n");
    return 0;
}
static int my_release(struct inode *inode, struct file *file)
{
    pr_info("file closed\n");
    return 0;
}
static ssize_t my_read(struct file *file, char __user *buf,size_t len, loff_t *ppos)
{
    pr_info("req for read\n");
    if(copy_to_user(buf,kbuff,len))
        return -EFAULT;
    return len;
}
static ssize_t my_write(struct file *file, const char __user *buf,size_t len, loff_t *ppos)
{
    pr_info("reg for write\n");
    if(copy_from_user(kbuff,buf,len))
        return -EFAULT;
    return len;
}
static struct file_operations fops = {				
	.owner	 = THIS_MODULE,						
	.open	 = my_open,					
	.release = my_release,					
	.read	 = my_read,					
	.write	 = my_write,	
};
static struct class *my_class;
static int dyna_ent(void)
{
    pr_info("entering the code\n");
    alloc_chrdev_region(&dev_num,0,1,"dybhaskars");//file name
    cdev_init(&cdev,&fops);
    cdev_add(&cdev,dev_num,1);
    my_class=class_create("db_class");
    device_create(my_class,NULL,dev_num,NULL,"dybhaskars");//device file name
    return 0;
}
static void ex(void)
{
    pr_info("exiting the code\n");
    device_destroy(my_class,dev_num);
    class_destroy(my_class);
    cdev_del(&cdev);
    unregister_chrdev_region(dev_num,1);
}

module_init(dyna_ent);
module_exit(ex);