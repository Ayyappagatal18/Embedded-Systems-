#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>

int main()
{
    int fd = -1;
    int choice;
    char wbuf[1024];
    char rbuf[1024];

    while (1)
    {
        printf("\n=== MENU ===\n");
        printf("1. Open device\n");
        printf("2. Write to device\n");
        printf("3. Read from device\n");
        printf("4. Exit\n");
        printf("Enter choice: ");
        scanf("%d", &choice);

        switch (choice)
        {
        case 1:
            fd = open("/dev/maa", O_RDWR);
            if (fd < 0)
                printf("Error: cannot open /dev/maa\n");
            else
                printf("Device opened successfully\n");
            break;

        case 2:
            if (fd < 0) {
                printf("Error: open the device first!\n");
                break;
            }

            // clear leftover newline from scanf
            while (getchar() != '\n');

            printf("Enter text: ");
            fgets(wbuf, sizeof(wbuf), stdin);

            // remove newline char
            wbuf[strcspn(wbuf, "\n")] = '\0';

            write(fd, wbuf, strlen(wbuf));
            printf("Write complete\n");
            break;

        case 3:
            if (fd < 0) {
                printf("Error: open the device first!\n");
                break;
            }

            memset(rbuf, 0, sizeof(rbuf));
            read(fd, rbuf, sizeof(rbuf));
            printf("Read data: %s\n", rbuf);
            break;

        case 4:
            if (fd >= 0)
                close(fd);
            printf("Exiting...\n");
            exit(0);

        default:
            printf("Invalid choice!\n");
        }
    }

    return 0;
}
