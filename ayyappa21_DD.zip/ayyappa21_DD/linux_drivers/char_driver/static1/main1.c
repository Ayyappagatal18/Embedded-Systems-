#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/init.h>
#include <linux/fs.h>
#include <linux/cdev.h>
#include <linux/uaccess.h>

dev_t dev = MKDEV(230, 0);

static char buff[1024];     // main storage buffer
static int wi = 0;          // write index (append position)

struct cdev mydev;

/* -------- OPEN -------- */
static int my_open(struct inode *inode, struct file *file)
{
    pr_info("device opened\n");
    return 0;
}

/* -------- RELEASE -------- */
static int my_release(struct inode *inode, struct file *file)
{
    pr_info("device closed\n");
    return 0;
}

/* -------- READ -------- */
static ssize_t my_read(struct file *file, char __user *buf, size_t len, loff_t *ppos)
{
    int ret_len;

    // if buffer empty
    if (wi == 0)
        return 0;

    ret_len = wi + 1;             // include null terminator

    if (ret_len > len)
        ret_len = len;

    if (copy_to_user(buf, buff, ret_len))
        return -EFAULT;

    return ret_len;
}

/* -------- WRITE (APPEND) -------- */
static ssize_t my_write(struct file *file, const char __user *buf, size_t len, loff_t *ppos)
{
    // prevent overflow
    if (wi + len >= sizeof(buff))
        len = sizeof(buff) - wi - 1;

    if (copy_from_user(buff + wi, buf, len))
        return -EFAULT;

    wi += len;
    buff[wi] = '\0';   // keep as string

    pr_info("write done, current buffer: %s\n", buff);

    return len;
}

/* -------- FILE OPERATIONS -------- */
static const struct file_operations fops = {
    .owner   = THIS_MODULE,
    .open    = my_open,
    .release = my_release,
    .read    = my_read,
    .write   = my_write,
};

/* -------- INIT -------- */
static int __init pi(void)
{
    int a;

    pr_info("module init\n");

    a = register_chrdev_region(dev, 1, "sai");
    if (a < 0)
    {
        pr_info("register failed\n");
        return a;
    }

    cdev_init(&mydev, &fops);

    if (cdev_add(&mydev, dev, 1) < 0)
    {
        pr_info("cdev_add failed\n");
        unregister_chrdev_region(dev, 1);
        return -1;
    }

    pr_info("driver loaded\n");
    return 0;
}

/* -------- EXIT -------- */
static void __exit pe(void)
{
    cdev_del(&mydev);
    unregister_chrdev_region(dev, 1);
    pr_info("module exit\n");
}

module_init(pi);
module_exit(pe);

MODULE_LICENSE("GPL");
