#include <stdio.h>
#include <string.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

int main()
{
    int fd = -1;   // keep fd global inside loop

    while (1)
    {
        int ch;
        printf("\nSelect option:\n1. Open file\n2. Write file\n3. Read file\n");
        scanf("%d", &ch);

        switch (ch)
        {
        case 1:
            fd = open("/dev/sai", O_RDWR);
            if (fd < 0)
                printf("File open error\n");
            else
                printf("File opened successfully\n");
            break;

        case 2:
            if (fd < 0)
            {
                printf("Please open file first!\n");
                break;
            }

            char wbuf[1024];
            printf("Enter text to write: ");
            fgets(wbuf, sizeof(wbuf), stdin);
               wbuf[strcspn(wbuf, "\n")] = '\0';


            write(fd, wbuf, strlen(wbuf));   // WRITE FULL STRING
            printf("Write done\n");
            break;

        case 3:
            if (fd < 0)
            {
                printf("Please open file first!\n");
                break;
            }

            char rbuf[1024] = {0};
            read(fd, rbuf, sizeof(rbuf));
            printf("Read: %s\n", rbuf);
            break;

        default:
            printf("Invalid option\n");
        }
    }

    return 0;
}
