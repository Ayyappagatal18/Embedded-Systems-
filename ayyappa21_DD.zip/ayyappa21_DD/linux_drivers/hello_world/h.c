#include<linux/module.h>
#include<linux/init.h>
#include<linux/kernel.h>
MODULE_LICENSE("GPL");
static int program_init(void)
{
    pr_info("module intialized\n");
    printk(KERN_INFO "HELLO WORLD\n");
    return 0;
}
static void program_exit(void)
{
    pr_info("module_exit\n");
     printk(KERN_ALERT "HELLO WORLD\n");

}
module_init(program_init);
module_exit(program_exit);