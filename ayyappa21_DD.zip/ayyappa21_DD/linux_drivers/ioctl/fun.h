#define our_reset _IO(2000,1)
#define our_read  _IOR(2000,2,char)
#define our_write _IOW(2000,3,char)