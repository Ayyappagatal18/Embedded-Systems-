#include<stdio.h>
#include<string.h>
#include<fcntl.h>
#include<unistd.h>
#include<sys/ioctl.h>
#include "fun.h"
#define aa "/dev/devicefile"
int main()
{
    int fd;
    fd=open(aa,O_RDWR);
    char str[]="hello from user space\n";
    char buff[50];
    ioctl(fd,our_write,str);//to write
    ioctl(fd,our_read,buff);//to read
    ioctl(fd,our_reset);//to reset
    printf("%s",buff);//to print
    close(fd);
    return 0;
}