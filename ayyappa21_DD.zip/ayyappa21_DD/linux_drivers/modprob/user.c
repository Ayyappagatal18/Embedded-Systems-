#include<linux/init.h>
#include<linux/param.h>
#include<linux/module.h>
#include"add.h"
MODULE_LICENSE("GPL");

static int start(void)
{
    pr_warn("hello hi\n");
    pr_info("%d\n",add(5,6));
    return 0;
}
static void exit1(void)
{
    pr_warn("good bye\n");
}

module_init(start);
module_exit(exit1);