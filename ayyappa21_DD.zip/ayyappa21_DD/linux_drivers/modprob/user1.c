
#include<linux/module.h>
#include<linux/init.h>
#include<linux/param.h>
#include"add.h"
MODULE_LICENSE("GPL");
int a,b;
static int start(void)
{
    pr_info("hello form user\n");
    return 0;
}
int add(int a,int b)
{
    return a+b; 
}
EXPORT_SYMBOL(add);
static void end(void)
{
    pr_info("byr from user\n");
}

module_param(a,int,0600);
module_param(b,int,0600);
module_init(start);
module_exit(end);