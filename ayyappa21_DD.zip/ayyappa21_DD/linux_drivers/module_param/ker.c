#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>

static int a = 10;
static char *ch="sai";
static int b[10]={1,2};
static int c=3;
// c=strlen(b);
static int __init module_i(void)
{
    printk(KERN_ALERT "module initialized\n");
    pr_info("a = %d\n", a);
     pr_info("ch = %s\n", ch);
     pr_info("b=%d\n",b[2]);
    return 0;
}

static void __exit module_e(void)
{
    printk(KERN_INFO "module exited\n");
}

module_init(module_i);
module_exit(module_e);

// module parameter with correct permissions
module_param(a, int, S_IRUGO);
module_param(ch, charp, S_IRUGO);
// module_param(b[], int, S_IRUGO);
module_param_array(b, int, &c, S_IRUGO);

MODULE_LICENSE("GPL");
