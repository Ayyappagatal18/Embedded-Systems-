#include<stdio.h>
#include<fcntl.h>
#include<unistd.h>
#include<sys/ioctl.h>
#include "io.h"

int main() {
    int fd = open("/dev/led_driver", O_RDWR);
    int brightness=0;
    while(1)
    {
        
        // printf("Enter brightness (0-99): ");
        // scanf("%d", &brightness);
        // int time=brightness*9999;
        while(brightness<100) {
            ioctl(fd, LED_IOC_BRIGHTNESS, &brightness);
            brightness++;
            usleep(10000);
        }
        while(brightness>0)
        {
            ioctl(fd,LED_IOC_BRIGHTNESS,&brightness);
            brightness--;
            usleep(10000);
        }
    }
}