#include<linux/init.h>
#include<linux/module.h>
int a=10;
static int hello_init(void)
{
    pr_info("init module\n");
    return 0;
}
static void hello_exit(void)
{
    pr_info("exit module\n");
}
module_init(hello_init);
module_exit(hello_exit);
MODULE_LICENSE("GPL");
