#include <linux/module.h>
#include <linux/init.h>
#include <linux/interrupt.h>
#include <linux/kernel.h>
#include <linux/jiffies.h>

MODULE_LICENSE("GPL");
MODULE_AUTHOR("sai");
MODULE_DESCRIPTION("Tasklet example for kernel 6.14");

// -------- TASKLET CALLBACK (new style) --------
static void my_tasklet_function(struct tasklet_struct *t)
{
    pr_info("TASKLET_EX: Tasklet executed! jiffies=%lu\n", jiffies);
}

// -------- DECLARE TASKLET (2-arg macro) --------
DECLARE_TASKLET(my_tasklet, my_tasklet_function);

// -------- MODULE INIT --------
static int __init tasklet_example_init(void)
{
    pr_info("TASKLET_EX: Module loaded, scheduling tasklet...\n");

    // Schedule the tasklet to run soon in softirq context
    tasklet_schedule(&my_tasklet);

    return 0;
}

// -------- MODULE EXIT --------
static void __exit tasklet_example_exit(void)
{
    pr_info("TASKLET_EX: Module unloading... killing tasklet\n");

    // Wait for tasklet to finish if it is running, then kill
    tasklet_kill(&my_tasklet);

    pr_info("TASKLET_EX: Module unloaded\n");
}

module_init(tasklet_example_init);
module_exit(tasklet_example_exit);
