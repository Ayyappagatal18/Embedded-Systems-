#include <linux/module.h>
#include <linux/init.h>
#include <linux/timer.h>
#include <linux/jiffies.h>
#include <linux/kernel.h>

MODULE_LICENSE("GPL");
MODULE_AUTHOR("sai-demo");
MODULE_DESCRIPTION("Simple kernel timer example");

static struct timer_list my_timer;
static unsigned int fire_count;

static void my_timer_callback(struct timer_list *t)
{
    fire_count++;
    pr_info("TIMER_EX: callback called %u times, jiffies=%lu\n",fire_count, jiffies);
    printk("iam in timer callback\n");

    // Re-arm timer every 2 seconds
    mod_timer(&my_timer, jiffies + msecs_to_jiffies(5000));
}

static int __init timer_example_init(void)
{
    pr_info("TIMER_EX: module loaded\n");

    // Initialize timer
    timer_setup(&my_timer, my_timer_callback, 0);
    // #define timer_setup(timer, callback, flags)			
	// __init_timer((timer), (callback), (flags))

    // First expiry after 2 seconds
    mod_timer(&my_timer, jiffies + msecs_to_jiffies(2000));
    // extern int mod_timer(struct timer_list *timer, unsigned long expires);

    return 0;
}

static void __exit timer_example_exit(void)
{
    int ret;

    // Safely delete timer (wait if callback is running)
    // ret = 
    del_timer_sync(&my_timer);
    // pr_info("TIMER_EX: module unloaded, timer was %sactive\n",ret ? "" : "in");
}

module_init(timer_example_init);
module_exit(timer_example_exit);
