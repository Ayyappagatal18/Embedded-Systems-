#include<stdio.h>
#include<string.h>
#include <fcntl.h>
#include <unistd.h>

int main()
{
    int fp,a;
    char buf1[1024],buf2[1024];

    fp = open("/dev/queue_device",O_RDWR);
    if(fp < 0)
    {
        printf("Failed to open device\n");
        return 0;
    }

    while(1)
    {
        printf("1. read\n2. write\n");
        scanf("%d",&a);

        switch(a)
        {
            case 1:
                memset(buf2, 0, sizeof(buf2));
                read(fp, buf2, sizeof(buf2));
                printf("Received from kernel: %s\n", buf2);
                break;

            case 2:
                printf("Enter text: ");
                scanf("%s", buf1);   // use fgets if needed
                write(fp, buf1, strlen(buf1));
                break;
        }
    }

    close(fp);
    return 0;
}
