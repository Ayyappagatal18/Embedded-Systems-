#include <linux/module.h>
#include <linux/init.h>
#include <linux/workqueue.h>
#include <linux/delay.h>
#include <linux/kernel.h>

MODULE_LICENSE("GPL");
MODULE_AUTHOR("sai-demo");
MODULE_DESCRIPTION("Simple workqueue example");

static struct workqueue_struct *my_wq;

struct my_work {
    struct work_struct work;
    int value;
};

static struct my_work work_item;

static void my_wq_function(struct work_struct *work)
{
    struct my_work *w;

    w = container_of(work, struct my_work, work);

    pr_info("WQ_EX: work started, value=%d, going to sleep\n", w->value);

    // Allowed here because workqueue runs in process context
    msleep(1000);

    pr_info("WQ_EX: work finished after sleep\n");
}

static int __init workqueue_example_init(void)
{
    pr_info("WQ_EX: module loaded\n");

    my_wq = alloc_workqueue("my_wq", WQ_UNBOUND, 0);
    if (!my_wq) {
        pr_err("WQ_EX: failed to create workqueue\n");
        return -ENOMEM;
    }

    work_item.value = 42;
    INIT_WORK(&work_item.work, my_wq_function);

    queue_work(my_wq, &work_item.work);
    pr_info("WQ_EX: queued one work item\n");

    return 0;
}

static void __exit workqueue_example_exit(void)
{
    pr_info("WQ_EX: flushing and destroying workqueue\n");

    if (my_wq) {
        flush_workqueue(my_wq);  // wait until all work is done
        destroy_workqueue(my_wq);
    }

    pr_info("WQ_EX: module unloaded\n");
}

module_init(workqueue_example_init);
module_exit(workqueue_example_exit);
