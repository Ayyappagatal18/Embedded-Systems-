#include<linux/init.h>
#include<linux/module.h>
#include "asd.h"
MODULE_LICENSE("GPL");
int add(int a,int b)
{
    return a+b;
}
EXPORT_SYMBOL(add);
static int m_init(void)
{
    pr_info("hiiiiii\n");
    return 0;
}
static void m_exit(void)
{
    pr_info("bye\n");
}
module_init(m_init);
module_exit(m_exit);