#include<linux/init.h>
#include<linux/module.h>
//#include<linux/param.h>
#include "asd.h"
MODULE_LICENSE("GPL");
static int m_init(void)
{
    //pr_info("hello/n");
    pr_info("add is = %d\n",add(6,5));
    pr_info("sub:%d\n",sub(5,2));
    return 0;
}
static void m_exit(void)
{
    pr_info("eXiT\n");
}
// module_param(h,int,S_IRUGO);
// module_param(i,int,S_IRUGO);
module_init(m_init);
module_exit(m_exit);
