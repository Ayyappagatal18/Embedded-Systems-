#include<linux/module.h>
#include<linux/init.h>
#include "asd.h"
MODULE_LICENSE("GPL");
int sub(int a,int b)
{
    return a-b;
}
EXPORT_SYMBOL(sub);
static int m_init(void)
{
    pr_info("hi\n");
    return 0;
}
static void m_exit(void)
{
    pr_info("bye\n");
}
module_init(m_init);
module_exit(m_exit);
