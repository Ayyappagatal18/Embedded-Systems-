#include<linux/module.h>
#include<linux/init.h>
#include<linux/kernel.h>

MODULE_LICENSE("GPL");
static int var=90;
static char *arr[]="sss";
static int __init my_init(void)
{
    pr_info("var:%d\n",var);
    pr_info("name:%s\n",arr);
    return 0;
}
static void __exit my_exit(void)
{
    pr_info( "Good Bye\n");
}
module_param(var,int,0666);
module_param(arr,charp,0666)
module_init(my_init);
module_exit(my_exit);
MODULE_AUTHOR("SHYAM");