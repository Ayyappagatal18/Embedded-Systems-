#include<linux/module.h>
#include<linux/kernel.h>
#include<linux/init.h>
#include<linux/param.h>
static int a = 10;
static char *k = "jbfds";
MODULE_LICENSE("GPL");
static int my_init(void)
{
    pr_info("val = %d\n",a);
    pr_info("str %s\n",k);
    return 0;
}
static void my_exit(void)
{
    pr_info("hi\n");
}
module_param(a,int,S_IRWXU);
module_param(k,charp,S_IRWXU);
module_init(my_init);
module_exit(my_exit);
