#include<stdio.h>
#include<string.h>
#include <fcntl.h>
#include <unistd.h>
int main()
{
    int fp,a;
    char buf1[1024],buf2[1024];
    fp = open("/dev/mq_file",O_RDWR); 
    printf("1.read\n2.write\n");
    scanf("%d",&a);
    switch(a)
    {
        case 1:
        {
            read(fp,buf2,sizeof(buf2));
            printf("%s\n",buf2);
            break;
        }
        case 2:
        {
            printf("enter \n");
            // gets(buf1);
            scanf("%99[^\n]",buf1);
            write(fp,buf1,strlen(buf1));
            break;
        }
    }
    close(fp);
    return 0;
}