#include<stdio.h>
#include<unistd.h>
#include<fcntl.h>
#include<string.h>
#define MY_DEVFILE_NAME "/dev/myDevFile"
int main()
{
    char str[50];
    char buff[]="hello from user\n";
    int fd;
    fd=open(MY_DEVFILE_NAME,O_RDWR);
    if(fd==-1)
    {
        printf("error\n");
        return 1;
    }
    write(fd,buff,strlen(buff)+1);
    read(fd,str,sizeof(str));
    printf("%s",str);
    close(fd);
}


